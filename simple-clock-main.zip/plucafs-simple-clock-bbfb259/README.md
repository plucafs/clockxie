# simple-clock
A simple clock and countdown timer made in Godot.
